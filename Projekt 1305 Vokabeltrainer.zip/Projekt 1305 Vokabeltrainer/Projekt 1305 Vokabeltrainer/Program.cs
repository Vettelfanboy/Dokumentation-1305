﻿namespace Projekt_1305_Vokabeltrainer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Liste der Vokabeln (Deutsch -> Englisch)
            Dictionary<string, string> vocabulary = new Dictionary<string, string>()
        {
            { "Apfel", "apple" },
            { "Buch", "book" },
            { "Katze", "cat" },
            { "Hund", "dog" },
            { "Haus", "house" },
            { "Auto", "car" },
            { "Baum", "tree" },
            { "Sonne", "sun" },
            { "Mond", "moon" },
            { "Wasser", "water" },
            { "Feuer", "fire" },
            { "Erde", "earth" },
            { "Luft", "air" },
            { "Brot", "bread" },
            { "Milch", "milk" },
            { "Käse", "cheese" },
            { "Schule", "school" },
            { "Lehrer", "teacher" },
            { "Schüler", "student" },
            { "Freund", "friend" },
            { "Stadt", "city" },
            { "Land", "country" },
            { "Computer", "computer" },
            { "Telefon", "phone" },
            { "Musik", "music" },
            { "Film", "movie" },
            { "Sprache", "language" },
            { "Essen", "food" },
            { "Getränk", "drink" },
            { "Liebe", "love" },
            { "Glück", "luck" },
            { "Traurigkeit", "sadness" },
            { "Familie", "family" },
            { "Bruder", "brother" },
            { "Schwester", "sister" },
            { "Mutter", "mother" },
            { "Vater", "father" },
            { "Kind", "child" },
            { "Arbeit", "work" },
            { "Beruf", "job" },
            { "Geld", "money" },
            { "Bank", "bank" },
            { "Restaurant", "restaurant" },
            { "Hotel", "hotel" },
            { "Flughafen", "airport" },
            { "Zug", "train" },
            { "Bus", "bus" },
            { "Taxi", "taxi" },
            { "Arzt", "doctor" },
            { "Krankenschwester", "nurse" },
            { "Krankenhaus", "hospital" },
            { "Medizin", "medicine" },
            { "Buchhandlung", "bookstore" },
            { "Bibliothek", "library" },
            { "Supermarkt", "supermarket" },
            { "Markt", "market" },
            { "Park", "park" },
            { "Strand", "beach" },
            { "Berg", "mountain" },
            { "Fluss", "river" },
            { "See", "lake" },
            { "Wald", "forest" },
            { "Tier", "animal" },
            { "Vogel", "bird" },
            { "Fisch", "fish" },
            { "Insekt", "insect" },
            { "Blume", "flower" },
            { "Gras", "grass" },
            { "Wetter", "weather" },
            { "Regen", "rain" },
            { "Schnee", "snow" },
            { "Wind", "wind" },
            { "Sturm", "storm" },
            { "Wolke", "cloud" },
            { "Himmel", "sky" },
            { "Stern", "star" },
            { "Universum", "universe" }
        };

            Console.WriteLine("Willkommen zum Deutsch/Englisch Vokabeltrainer!");
            Console.WriteLine("Geben Sie die englische Übersetzung des deutschen Wortes ein.\n");

            // Hauptschleife des Programms
            while (true)
            {
                foreach (var word in vocabulary)
                {
                    Console.Write($"Wie lautet die englische Übersetzung für '{word.Key}'? ");
                    string answer = Console.ReadLine();

                    if (answer.ToLower() == word.Value.ToLower())
                    {
                        Console.WriteLine("Richtig!\n");
                    }
                    else
                    {
                        Console.WriteLine($"Falsch. Die richtige Antwort ist '{word.Value}'.\n");
                    }
                }

                Console.Write("Möchten Sie die Vokabeln noch einmal durchgehen? (ja/nein): ");
                string repeat = Console.ReadLine().ToLower();

                if (repeat != "ja")
                {
                    break;
                }

                Console.WriteLine();
            }

            Console.WriteLine("Danke fürs Spielen! Auf Wiedersehen.");
        }
    }
}
    

